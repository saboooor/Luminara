item modify entity @s nova_structures:chart_bundle_check nova_structures:chart_bundle_ready

advancement revoke @s only nova_structures:charts/bundle_check