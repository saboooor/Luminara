execute if predicate {predicate:{structures:"#nova_structures:vanilla/end"},type:"minecraft:location_check"} run function nova_structures:structure_search/vanilla/end

execute if predicate {predicate:{structures:"#nova_structures:vanilla/nether"},type:"minecraft:location_check"} run function nova_structures:structure_search/vanilla/nether

execute if predicate {predicate:{structures:"#nova_structures:vanilla/overworld"},type:"minecraft:location_check"} run function nova_structures:structure_search/vanilla/overworld

execute if predicate {predicate:{structures:"#nova_structures:vanilla/overworld_buried"},type:"minecraft:location_check"} run function nova_structures:structure_search/vanilla/overworld_buried

execute if predicate {predicate:{structures:"#nova_structures:vanilla/overworld_water"},type:"minecraft:location_check"} run function nova_structures:structure_search/vanilla/overworld_water