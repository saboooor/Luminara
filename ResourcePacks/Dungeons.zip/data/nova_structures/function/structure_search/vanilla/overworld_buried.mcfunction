execute if predicate {predicate:{structures:"minecraft:ancient_city"},type:"minecraft:location_check"} run tell @s minecraft:ancient_city

execute if predicate {predicate:{structures:"minecraft:buried_treasure"},type:"minecraft:location_check"} run tell @s minecraft:buried_treasure

execute if predicate {predicate:{structures:"minecraft:mineshaft"},type:"minecraft:location_check"} run tell @s minecraft:mineshaft

execute if predicate {predicate:{structures:"minecraft:mineshaft_mesa"},type:"minecraft:location_check"} run tell @s minecraft:mineshaft_mesa

execute if predicate {predicate:{structures:"minecraft:stronghold"},type:"minecraft:location_check"} run tell @s minecraft:stronghold

execute if predicate {predicate:{structures:"minecraft:trail_ruins"},type:"minecraft:location_check"} run tell @s minecraft:trail_ruins

execute if predicate {predicate:{structures:"minecraft:trial_chambers"},type:"minecraft:location_check"} run tell @s minecraft:trial_chambers