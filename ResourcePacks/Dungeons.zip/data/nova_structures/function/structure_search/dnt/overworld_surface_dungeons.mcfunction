execute if predicate {predicate:{structures:"nova_structures:surface_dungeon_default"},type:"minecraft:location_check"} run tell @s nova_structures:surface_dungeon_default

execute if predicate {predicate:{structures:"nova_structures:surface_dungeon_desert"},type:"minecraft:location_check"} run tell @s nova_structures:surface_dungeon_desert

execute if predicate {predicate:{structures:"nova_structures:surface_dungeon_snowy"},type:"minecraft:location_check"} run tell @s nova_structures:surface_dungeon_snowy

execute if predicate {predicate:{structures:"nova_structures:surface_dungeon_swamp"},type:"minecraft:location_check"} run tell @s nova_structures:surface_dungeon_swamp

execute if predicate {predicate:{structures:"nova_structures:surface_trial_dungeon_default"},type:"minecraft:location_check"} run tell @s nova_structures:surface_trial_dungeon_default

execute if predicate {predicate:{structures:"nova_structures:surface_trial_dungeon_desert"},type:"minecraft:location_check"} run tell @s nova_structures:surface_trial_dungeon_desert

execute if predicate {predicate:{structures:"nova_structures:surface_trial_dungeon_snowy"},type:"minecraft:location_check"} run tell @s nova_structures:surface_trial_dungeon_snowy

execute if predicate {predicate:{structures:"nova_structures:surface_trial_dungeon_swamp"},type:"minecraft:location_check"} run tell @s nova_structures:surface_trial_dungeon_swamp