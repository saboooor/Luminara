execute if predicate {predicate:{structures:"nova_structures:shrine_combat_tier_1"},type:"minecraft:location_check"} run tell @s nova_structures:shrine_combat_tier_1

execute if predicate {predicate:{structures:"nova_structures:shrine_combat_tier_2"},type:"minecraft:location_check"} run tell @s nova_structures:shrine_combat_tier_2

execute if predicate {predicate:{structures:"nova_structures:shrine_combat_tier_3"},type:"minecraft:location_check"} run tell @s nova_structures:shrine_combat_tier_3

execute if predicate {predicate:{structures:"nova_structures:shrine_combat_tier_4"},type:"minecraft:location_check"} run tell @s nova_structures:shrine_combat_tier_4

execute if predicate {predicate:{structures:"nova_structures:shrine_combat_tier_5"},type:"minecraft:location_check"} run tell @s nova_structures:shrine_combat_tier_5

execute if predicate {predicate:{structures:"nova_structures:shrine_biome_tier_1"},type:"minecraft:location_check"} run tell @s nova_structures:shrine_biome_tier_1

execute if predicate {predicate:{structures:"nova_structures:shrine_biome_tier_2"},type:"minecraft:location_check"} run tell @s nova_structures:shrine_biome_tier_2

execute if predicate {predicate:{structures:"nova_structures:shrine_biome_tier_3"},type:"minecraft:location_check"} run tell @s nova_structures:shrine_biome_tier_3

execute if predicate {predicate:{structures:"nova_structures:shrine_biome_tier_4"},type:"minecraft:location_check"} run tell @s nova_structures:shrine_biome_tier_4

execute if predicate {predicate:{structures:"nova_structures:shrine_biome_tier_5"},type:"minecraft:location_check"} run tell @s nova_structures:shrine_biome_tier_5