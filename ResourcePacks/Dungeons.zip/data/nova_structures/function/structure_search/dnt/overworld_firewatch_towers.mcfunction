execute if predicate {predicate:{structures:"nova_structures:firewatch_tower_birch"},type:"minecraft:location_check"} run tell @s nova_structures:firewatch_tower_birch

execute if predicate {predicate:{structures:"nova_structures:firewatch_tower_cherry"},type:"minecraft:location_check"} run tell @s nova_structures:firewatch_tower_cherry

execute if predicate {predicate:{structures:"nova_structures:firewatch_tower_dappled"},type:"minecraft:location_check"} run tell @s nova_structures:firewatch_tower_dappled

execute if predicate {predicate:{structures:"nova_structures:firewatch_tower_dark_oak"},type:"minecraft:location_check"} run tell @s nova_structures:firewatch_tower_dark_oak

execute if predicate {predicate:{structures:"nova_structures:firewatch_tower_forest"},type:"minecraft:location_check"} run tell @s nova_structures:firewatch_tower_forest

execute if predicate {predicate:{structures:"nova_structures:firewatch_tower_jungle"},type:"minecraft:location_check"} run tell @s nova_structures:firewatch_tower_jungle

execute if predicate {predicate:{structures:"nova_structures:firewatch_tower_mangrove"},type:"minecraft:location_check"} run tell @s nova_structures:firewatch_tower_mangrove

execute if predicate {predicate:{structures:"nova_structures:firewatch_tower_pale"},type:"minecraft:location_check"} run tell @s nova_structures:firewatch_tower_pale

execute if predicate {predicate:{structures:"nova_structures:firewatch_tower_savanna"},type:"minecraft:location_check"} run tell @s nova_structures:firewatch_tower_savanna

execute if predicate {predicate:{structures:"nova_structures:firewatch_tower_swamp"},type:"minecraft:location_check"} run tell @s nova_structures:firewatch_tower_swamp

execute if predicate {predicate:{structures:"nova_structures:firewatch_tower_taiga"},type:"minecraft:location_check"} run tell @s nova_structures:firewatch_tower_taiga