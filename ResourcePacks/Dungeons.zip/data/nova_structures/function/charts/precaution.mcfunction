advancement revoke @a only nova_structures:charts/using
advancement revoke @a only nova_structures:charts/unfolding