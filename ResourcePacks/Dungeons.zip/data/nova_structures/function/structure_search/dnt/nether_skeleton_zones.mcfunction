execute if predicate {predicate:{structures:"nova_structures:nether_skeleton_tower_crimson"},type:"minecraft:location_check"} run tell @s nova_structures:nether_skeleton_tower_crimson

execute if predicate {predicate:{structures:"nova_structures:nether_skeleton_tower_fort"},type:"minecraft:location_check"} run tell @s nova_structures:nether_skeleton_tower_fort

execute if predicate {predicate:{structures:"nova_structures:nether_skeleton_tower_soul"},type:"minecraft:location_check"} run tell @s nova_structures:nether_skeleton_tower_soul

execute if predicate {predicate:{structures:"nova_structures:nether_skeleton_tower_warped"},type:"minecraft:location_check"} run tell @s nova_structures:nether_skeleton_tower_warped

execute if predicate {predicate:{structures:"nova_structures:nether_skeleton_camp_crimson"},type:"minecraft:location_check"} run tell @s nova_structures:nether_skeleton_camp_crimson

execute if predicate {predicate:{structures:"nova_structures:nether_skeleton_camp_fort"},type:"minecraft:location_check"} run tell @s nova_structures:nether_skeleton_camp_fort

execute if predicate {predicate:{structures:"nova_structures:nether_skeleton_camp_soul"},type:"minecraft:location_check"} run tell @s nova_structures:nether_skeleton_camp_soul

execute if predicate {predicate:{structures:"nova_structures:nether_skeleton_camp_warped"},type:"minecraft:location_check"} run tell @s nova_structures:nether_skeleton_camp_warped
