execute if predicate {predicate:{structures:"nova_structures:tavern_acacia"},type:"minecraft:location_check"} run tell @s nova_structures:tavern_acacia

execute if predicate {predicate:{structures:"nova_structures:tavern_birch"},type:"minecraft:location_check"} run tell @s nova_structures:tavern_birch

execute if predicate {predicate:{structures:"nova_structures:tavern_cherry"},type:"minecraft:location_check"} run tell @s nova_structures:tavern_cherry

execute if predicate {predicate:{structures:"nova_structures:tavern_dappled"},type:"minecraft:location_check"} run tell @s nova_structures:tavern_dappled

execute if predicate {predicate:{structures:"nova_structures:tavern_dark_oak"},type:"minecraft:location_check"} run tell @s nova_structures:tavern_dark_oak

execute if predicate {predicate:{structures:"nova_structures:tavern_desert"},type:"minecraft:location_check"} run tell @s nova_structures:tavern_desert

execute if predicate {predicate:{structures:"nova_structures:tavern_jungle"},type:"minecraft:location_check"} run tell @s nova_structures:tavern_jungle

execute if predicate {predicate:{structures:"nova_structures:tavern_mangrove"},type:"minecraft:location_check"} run tell @s nova_structures:tavern_mangrove

execute if predicate {predicate:{structures:"nova_structures:tavern_oak"},type:"minecraft:location_check"} run tell @s nova_structures:tavern_oak

execute if predicate {predicate:{structures:"nova_structures:tavern_pale"},type:"minecraft:location_check"} run tell @s nova_structures:tavern_pale

execute if predicate {predicate:{structures:"nova_structures:tavern_snowy"},type:"minecraft:location_check"} run tell @s nova_structures:tavern_snowy

execute if predicate {predicate:{structures:"nova_structures:tavern_spruce"},type:"minecraft:location_check"} run tell @s nova_structures:tavern_spruce

execute if predicate {predicate:{structures:"nova_structures:tavern_swamp"},type:"minecraft:location_check"} run tell @s nova_structures:tavern_swamp

