execute if predicate {predicate:{structures:"#minecraft:abandoned_camp"},type:"minecraft:location_check"} run function nova_structures:structure_search/vanilla/overworld_abandoned_camp

execute if predicate {predicate:{structures:"minecraft:desert_pyramid"},type:"minecraft:location_check"} run tell @s minecraft:desert_pyramid

execute if predicate {predicate:{structures:"minecraft:igloo"},type:"minecraft:location_check"} run tell @s minecraft:igloo

execute if predicate {predicate:{structures:"minecraft:jungle_pyramid"},type:"minecraft:location_check"} run tell @s minecraft:jungle_pyramid

execute if predicate {predicate:{structures:"minecraft:mansion"},type:"minecraft:location_check"} run tell @s minecraft:mansion

execute if predicate {predicate:{structures:"minecraft:pillager_outpost"},type:"minecraft:location_check"} run tell @s minecraft:pillager_outpost

execute if predicate {predicate:{structures:"minecraft:swamp_hut"},type:"minecraft:location_check"} run tell @s minecraft:swamp_hut

execute if predicate {predicate:{structures:"minecraft:village_desert"},type:"minecraft:location_check"} run tell @s minecraft:village_desert

execute if predicate {predicate:{structures:"minecraft:village_plains"},type:"minecraft:location_check"} run tell @s minecraft:village_plains

execute if predicate {predicate:{structures:"minecraft:village_savanna"},type:"minecraft:location_check"} run tell @s minecraft:village_savanna

execute if predicate {predicate:{structures:"minecraft:village_snowy"},type:"minecraft:location_check"} run tell @s minecraft:village_snowy

execute if predicate {predicate:{structures:"minecraft:village_taiga"},type:"minecraft:location_check"} run tell @s minecraft:village_taiga